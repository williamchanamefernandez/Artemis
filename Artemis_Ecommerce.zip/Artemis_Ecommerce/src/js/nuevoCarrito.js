var muebleria = [
    { img: 'src/img/busqueda/hogar01.png', precio: 1300, marca: 'BASEMET HOME', descripcion: '1 sofá color marrón' },
    { img: 'src/img/busqueda/hogar02.jpeg', precio: 300, marca: 'MICA', descripcion: 'Juego de sala color verde' },
    { img: 'src/img/busqueda/hogar03.png', precio: 700, marca: 'MICA', descripcion: 'Juego de sala color Gris' },
    { img: 'src/img/busqueda/hogar04.jpg', precio: 1350, marca: 'PARAISO', descripcion: 'Colchón pocket start' },
    // 
    { img: 'src/img/busqueda/hogar05.jpg', precio: 1350, marca: 'PARAISO', descripcion: 'Colchón pocket start' },
    { img: 'src/img/busqueda/hogar06.jpg', precio: 1350, marca: 'PARAISO', descripcion: 'Colchón pocket start' },
    { img: 'src/img/busqueda/hogar07.jpg', precio: 1350, marca: 'PARAISO', descripcion: 'Colchón pocket start' },
    { img: 'src/img/busqueda/hogar08.jpg', precio: 1350, marca: 'PARAISO', descripcion: 'Colchón pocket start' },
    { img: 'src/img/busqueda/hogar09.jpg', precio: 1350, marca: 'PARAISO', descripcion: 'Colchón pocket start' },
];

var tecno = [
    { img: 'src/img/busqueda/tecnologia01.jpeg', precio: 2300, marca: 'HP', descripcion: 'Laptop hp Pavillon i5' },
    { img: 'src/img/busqueda/tecnologia02.jpg', precio: 5300, marca: 'APPLE', descripcion: 'Iphone 11' },
    { img: 'src/img/busqueda/tecnologia03.jpg', precio: 1100, marca: 'SAMSUNG', descripcion: 'Samsung Galaxy A24' },
    { img: 'src/img/busqueda/tecnologia04.jpg', precio: 300, marca: 'LENOVO', descripcion: 'Audifonos Bluetooth' },
    // 
    { img: 'src/img/busqueda/hogar01.png', precio: 2300, marca: 'HP', descripcion: 'Laptop hp Pavillon i5' },
];
