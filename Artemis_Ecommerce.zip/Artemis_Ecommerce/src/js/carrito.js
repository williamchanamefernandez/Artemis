let carritoCompras = [];
let lista = document.querySelector('.lista-carrito tbody');
let sumaTotal = 0;
let subTotal = document.querySelector('.total-venta');
// Se necesita tener un contenedor padre pora todos los productos
let listaProductos = document.querySelector('.listaProductos');
let enviarCompra = document.querySelector('.enviar-compra1');
// Boton de nueva compra que vacia mi carrito
let nuevaCompra = document.querySelector('.nueva-compra1');
let carrito = document.querySelector('.carrito-compras');
let cantidadCarrito = document.querySelector('#cantidadCarrito');
// 
let controles = document.querySelector('.control');

general();
function general() {
    listaProductos.addEventListener('click', xxx);
    listaProductos.addEventListener('click', calcularTotal);
    enviarCompra.addEventListener('click', enviarCompraFn);
    nuevaCompra.addEventListener('click', function () {
        carritoCompras = [...[]];
        iterarEnHTml(carritoCompras);
        document.querySelector('.total-venta').value = '';
        document.querySelector('.apellidos1').value = '';
        document.querySelector('.email1').value = '';
    });
    carrito.addEventListener('click', eliminarElemento);
    document.addEventListener('DOMContentLoaded', () => {
        carritoCompras = JSON.parse(localStorage.getItem('carrito')) || [];
        calcularTotal();
        iterarEnHTml(carritoCompras);
    });
    controles.addEventListener('click', xxx1);
}

function xxx(e) {
    e.preventDefault();
    if (e.target.classList.contains('btn-primary')) {

        let productoSeleccionado = e.target.parentElement.parentElement;
        leerDatosProducto(productoSeleccionado);
    }
}

function xxx1(e) {
    e.preventDefault();
    if (e.target.classList.contains('masCantidad')) {
        let pSeleccionado = e.target.parentElement;
        sumar(pSeleccionado);
    }
    if (e.target.classList.contains('menosCantidad')) {
        let pSeleccionado = e.target.parentElement;
        restar(pSeleccionado);
    }
}

function sumar(p) {
    p.querySelector('#cantidadUnidad').value = parseInt(p.querySelector('#cantidadUnidad').value) + 1;
}

function restar(p) {
    if (p.querySelector('#cantidadUnidad').value > 0) {

        p.querySelector('#cantidadUnidad').value = parseInt(p.querySelector('#cantidadUnidad').value) - 1;
    }
}

function enviarCompraFn() {
    let cajaModal = document.querySelector('.cajaModal');
    var monederoRadioButton = document.getElementById('monedero');
    if (monederoRadioButton.checked) {
        cajaModal.querySelector('.total').value = document.querySelector('.total-venta').value - document.querySelector('.total-venta').value * 0.1;
    } else {
        cajaModal.querySelector('.total').value = document.querySelector('.total-venta').value;
    }
    cajaModal.querySelector('.Apellidos').value = document.querySelector('.apellidos1').value;
    cajaModal.querySelector('.email').value = document.querySelector('.email1').value;
}


function eliminarElemento(e) {
    e.preventDefault();
    if (e.target.classList.contains('btn-close')) {
        proId = e.target.getAttribute('data-id');
        carritoCompras = carritoCompras.filter(producto => producto.id !== proId);
    }
    iterarEnHTml(carritoCompras);
    calcularTotal();
}

function leerDatosProducto(curso) {
    document.querySelector('#cantidadUnidad').value = 1;
    // Se emplead query Selector para acceder al nodo hijo
    let objeto = {
        img: curso.querySelector('.card-img-top').src,
        nombre: curso.querySelector('.card-title').textContent,
        precio: curso.querySelector('.card-text').textContent,
        id: curso.querySelector('a').getAttribute('data-id'),
        cantidad: 1,
    }



    // Revisa si un elemento ya existe en el carrito
    const existe = carritoCompras.some(curso => curso.id === objeto.id);

    if (existe) {
        const cursos = carritoCompras.map(curso => {
            if (curso.id === objeto.id) {
                curso.cantidad += objeto.cantidad;
                return curso;
            } else {
                return curso;
            }
        });
        carritoCompras = [...cursos];
    } else {
        // Agrega elementos al arreglo de carrito
        carritoCompras = [...carritoCompras, objeto];
    }

    iterarEnHTml(carritoCompras);
    curso.querySelector('.form-control').value = "";
}

function calcularTotal() {
    sumaTotal = 0;
    carritoCompras.map(function (producto) {
        sumaTotal += producto.precio * producto.cantidad;
    });
    subTotal.value = sumaTotal;
}

function eliminar(e) {
    if (e.target.classList.contains('btn-close')) {
        const idd = e.target.getAttribute('data-id');
        carritoCompras = carritoCompras.filter(producto => producto.id !== idd);

        iterarEnHTml();
    }
}

function sincronizarStorage() {
    localStorage.setItem('carrito', JSON.stringify(carritoCompras));
}

function iterarEnHTml(carrito) {
    limpiar();
    let cantidad1 = 0;
    carritoCompras.forEach(function (p) {
        cantidad1 += p.cantidad;
    });
    cantidadCarrito.textContent = ` ( ${cantidad1} ) `;
    carrito.forEach(function (producto) {
        const row = document.createElement('tr');
        row.innerHTML = ` 
            <td>
             <a href="#" class="btn btn-primary btn-close" data-id = "${producto.id}"></a>
            </td>  
            <td>
                <img src="${producto.img}" alt="" class="img-fluid" width=100>
            </td>        
            <td>
                ${producto.nombre}
            </td>
            <td>
                ${producto.precio}
            </td>
            <td>
                ${producto.cantidad}
            </td>
            <td>
                ${producto.precio * producto.cantidad}
            </td>
            `;

        // Agregar el html del carrito en el table body
        lista.appendChild(row);
    });

    sincronizarStorage();
}

function limpiar() {
    while (lista.firstChild) {
        lista.removeChild(lista.firstChild);
    }
}

